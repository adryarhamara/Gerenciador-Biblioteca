# Gerenciador-Biblioteca
Projeto acadêmico em Java com o objetivo de desenvolver uma aplicação web para gerenciar bibliotecas de universidades e escolas.
